rocks_trees = {
   { name = [[system]], root = [[/home/ubuntu/workspace/TH3BOSS/.luarocks]] }
}
